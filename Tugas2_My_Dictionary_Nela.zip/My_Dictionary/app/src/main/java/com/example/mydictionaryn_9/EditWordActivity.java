package com.example.mydictionaryn_9;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class EditWordActivity extends AppCompatActivity {

    // Key untuk passing data via Intent
    public static final String EXTRA_ID       = "extra_id";
    public static final String EXTRA_ENGLISH  = "extra_english";
    public static final String EXTRA_INDONESIA = "extra_indonesia";

    private EditText etEditEnglish;
    private EditText etEditIndonesia;
    private TextView tvEditMessage;

    private DictionaryDbHelper dbHelper;
    private int wordId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_edit_word);

        dbHelper       = new DictionaryDbHelper(this);
        etEditEnglish  = findViewById(R.id.etEditEnglish);
        etEditIndonesia = findViewById(R.id.etEditIndonesia);
        tvEditMessage  = findViewById(R.id.tvEditMessage);

        Button btnSaveEdit   = findViewById(R.id.btnSaveEdit);
        Button btnCancelEdit = findViewById(R.id.btnCancelEdit);

        // ── Ambil data dari Intent ────────────────────────────────
        wordId = getIntent().getIntExtra(EXTRA_ID, -1);
        String english   = getIntent().getStringExtra(EXTRA_ENGLISH);
        String indonesia = getIntent().getStringExtra(EXTRA_INDONESIA);

        // ── Isi form dengan data yang ada ─────────────────────────
        etEditEnglish.setText(english);
        etEditIndonesia.setText(indonesia);

        btnSaveEdit.setOnClickListener(v -> saveChanges());
        btnCancelEdit.setOnClickListener(v -> finish());
    }

    private void saveChanges() {

        // Sembunyikan pesan sebelumnya
        tvEditMessage.setVisibility(View.GONE);

        String newEnglish   = etEditEnglish.getText().toString().trim();
        String newIndonesia = etEditIndonesia.getText().toString().trim();

        // ── Validasi tidak boleh kosong ───────────────────────────
        if (newEnglish.isEmpty() || newIndonesia.isEmpty()) {
            tvEditMessage.setText("English dan Indonesia tidak boleh kosong!");
            tvEditMessage.setTextColor(0xFFD32F2F);
            tvEditMessage.setVisibility(View.VISIBLE);
            return;
        }

        // ── Validasi ID valid ─────────────────────────────────────
        if (wordId == -1) {
            Toast.makeText(this, "ID tidak valid!", Toast.LENGTH_SHORT).show();
            return;
        }

        // ── Eksekusi update ke database ───────────────────────────
        int updated = dbHelper.updateEntry(wordId, newEnglish, newIndonesia);

        if (updated > 0) {
            tvEditMessage.setText("Berhasil diperbarui!");
            tvEditMessage.setTextColor(0xFF388E3C);
            tvEditMessage.setVisibility(View.VISIBLE);

            // Kembali ke WordListActivity setelah 800ms
            tvEditMessage.postDelayed(() -> finish(), 800);

        } else {
            tvEditMessage.setText("Gagal memperbarui. Kata mungkin sudah ada!");
            tvEditMessage.setTextColor(0xFFD32F2F);
            tvEditMessage.setVisibility(View.VISIBLE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) dbHelper.close();
    }
}