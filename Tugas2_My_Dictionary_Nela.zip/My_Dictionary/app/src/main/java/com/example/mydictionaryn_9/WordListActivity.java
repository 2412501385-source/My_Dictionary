package com.example.mydictionaryn_9;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class WordListActivity extends AppCompatActivity {

    private RecyclerView rvWords;
    private WordAdapter  adapter;
    private EditText     etSearch;

    private final List<Word>   allWords   = new ArrayList<>();
    private final List<String> allEntries = new ArrayList<>();

    private final List<Word>   words   = new ArrayList<>();
    private final List<String> entries = new ArrayList<>();

    private DictionaryDbHelper dbHelper;
    private TextView tvEmpty;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_word_list);

        dbHelper = new DictionaryDbHelper(this);
        rvWords  = findViewById(R.id.rvWords);
        tvEmpty  = findViewById(R.id.tvEmpty);
        etSearch = findViewById(R.id.etSearch);

        Button btnBack           = findViewById(R.id.btnBack);
        Button btnDeleteSelected = findViewById(R.id.btnDeleteSelected);

        // ── Setup RecyclerView ────────────────────────────────────
        adapter = new WordAdapter(entries, words);
        rvWords.setLayoutManager(new LinearLayoutManager(this));
        rvWords.setAdapter(adapter);

        // ── Listener tombol Edit di setiap item ───────────────────
        adapter.setOnEditClickListener(position -> {
            if (position < 0 || position >= words.size()) return;
            Word w = words.get(position);

            Intent intent = new Intent(this, EditWordActivity.class);
            intent.putExtra(EditWordActivity.EXTRA_ID,        w.getId());
            intent.putExtra(EditWordActivity.EXTRA_ENGLISH,   w.getEnglish());
            intent.putExtra(EditWordActivity.EXTRA_INDONESIA, w.getIndonesia());
            startActivity(intent);
        });

        btnBack.setOnClickListener(v -> finish());
        btnDeleteSelected.setOnClickListener(v -> deleteSelected());

        // ── Search realtime ───────────────────────────────────────
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start,
                                          int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start,
                                      int before, int count) {
                filterWords(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) {}
        });

        loadWords();
    }

    private void filterWords(String keyword) {

        words.clear();
        entries.clear();

        String query = keyword.trim().toLowerCase();

        if (query.isEmpty()) {
            words.addAll(allWords);
            entries.addAll(allEntries);
        } else {
            for (int i = 0; i < allWords.size(); i++) {
                Word w = allWords.get(i);
                boolean matchEnglish   = w.getEnglish().toLowerCase().contains(query);
                boolean matchIndonesia = w.getIndonesia().toLowerCase().contains(query);
                if (matchEnglish || matchIndonesia) {
                    words.add(w);
                    entries.add(allEntries.get(i));
                }
            }
        }

        adapter.clearSelection();
        adapter.notifyDataSetChanged();
        updateEmptyView();
    }

    private void deleteSelected() {

        int pos = adapter.getSelectedPosition();

        if (pos < 0) {
            Toast.makeText(this,
                    "Pilih kata yang ingin dihapus terlebih dahulu",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        if (pos >= words.size()) return;

        Word w = words.get(pos);

        new AlertDialog.Builder(this)
                .setTitle("Konfirmasi Hapus")
                .setMessage("Yakin ingin menghapus kata:\n\n\""
                        + w.getEnglish() + "  →  " + w.getIndonesia() + "\" ?")
                .setIcon(android.R.drawable.ic_dialog_alert)

                .setPositiveButton("Ya, Hapus", (dialog, which) -> {

                    int deleted = dbHelper.deleteById(w.id);

                    if (deleted > 0) {
                        int masterIndex = allWords.indexOf(w);
                        if (masterIndex >= 0) {
                            allWords.remove(masterIndex);
                            allEntries.remove(masterIndex);
                        }

                        words.remove(pos);
                        entries.remove(pos);

                        adapter.clearSelection();
                        adapter.notifyDataSetChanged();
                        updateEmptyView();

                        Toast.makeText(this,
                                "\"" + w.getEnglish() + "\" berhasil dihapus",
                                Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this,
                                "Gagal menghapus kata",
                                Toast.LENGTH_SHORT).show();
                    }
                })

                .setNegativeButton("Batal", (dialog, which) -> dialog.dismiss())
                .setCancelable(true)
                .show();
    }

    @Override
    protected void onResume() {
        super.onResume();
        loadWords();
    }

    private void loadWords() {

        List<Word> list = dbHelper.listAll();

        allWords.clear();
        allEntries.clear();
        words.clear();
        entries.clear();

        if (list != null) {
            for (Word w : list) {
                allWords.add(w);
                allEntries.add(w.english + " → " + w.indonesia);
            }
        }

        String currentQuery = etSearch != null
                ? etSearch.getText().toString()
                : "";

        if (!currentQuery.isEmpty()) {
            filterWords(currentQuery);
        } else {
            words.addAll(allWords);
            entries.addAll(allEntries);
            adapter.notifyDataSetChanged();
            updateEmptyView();
        }
    }

    private void updateEmptyView() {

        if (entries.isEmpty()) {
            String currentQuery = etSearch != null
                    ? etSearch.getText().toString().trim()
                    : "";

            tvEmpty.setText(currentQuery.isEmpty()
                    ? "Belum ada kata yang tersimpan"
                    : "Kata \"" + currentQuery + "\" tidak ditemukan");

            tvEmpty.setVisibility(View.VISIBLE);
        } else {
            tvEmpty.setVisibility(View.GONE);
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (dbHelper != null) dbHelper.close();
    }
}