package com.example.mydictionaryn_9;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class AddDataActivity extends AppCompatActivity {

    private EditText etEnglish;
    private EditText etIndonesia;
    private TextView tvAddMessage;
    private DictionaryDbHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_data);

        etEnglish = findViewById(R.id.etAddEnglish);
        etIndonesia = findViewById(R.id.etAddIndonesia);
        tvAddMessage = findViewById(R.id.tvAddMessage);

        dbHelper = new DictionaryDbHelper(this);

        Button btnSave = findViewById(R.id.btnSave);
        Button btnBack = findViewById(R.id.btnBack);

        btnSave.setOnClickListener(v -> saveData());
        btnBack.setOnClickListener(v -> finish());
    }

    private void saveData() {

        tvAddMessage.setVisibility(View.GONE);

        // Reset error dulu
        etEnglish.setError(null);
        etIndonesia.setError(null);

        String english = etEnglish.getText().toString().trim();
        String indonesia = etIndonesia.getText().toString().trim();

        // ✅ Validasi tidak boleh kosong
        if (english.isEmpty()) {
            etEnglish.setError("English word cannot be empty");
            etEnglish.requestFocus();
            return;
        }

        if (indonesia.isEmpty()) {
            etIndonesia.setError("Indonesian meaning cannot be empty");
            etIndonesia.requestFocus();
            return;
        }

        long id = dbHelper.addEntry(english, indonesia);

        if (id == -1) {
            tvAddMessage.setText("Failed to save. Maybe word already exists.");
            tvAddMessage.setVisibility(View.VISIBLE);
        } else {
            tvAddMessage.setText("Saved");
            tvAddMessage.setVisibility(View.VISIBLE);

            tvAddMessage.postDelayed(
                    () -> finish(),
                    800
            );
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        if (dbHelper != null) {
            dbHelper.close();
        }
    }
}