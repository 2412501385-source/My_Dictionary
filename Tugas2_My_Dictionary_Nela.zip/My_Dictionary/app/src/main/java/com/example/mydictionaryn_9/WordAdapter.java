package com.example.mydictionaryn_9;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class WordAdapter extends RecyclerView.Adapter<WordAdapter.WordViewHolder> {

    // ── Interface callback untuk tombol Edit ─────────────────────
    public interface OnEditClickListener {
        void onEditClick(int position);
    }

    private final List<String>      entries;
    private final List<Word>        words;
    private       OnEditClickListener editListener;
    private       int               selectedPosition = -1;

    public WordAdapter(List<String> entries, List<Word> words) {
        this.entries = entries;
        this.words   = words;
    }

    public void setOnEditClickListener(OnEditClickListener listener) {
        this.editListener = listener;
    }

    public int getSelectedPosition() {
        return selectedPosition;
    }

    public void clearSelection() {
        int prev = selectedPosition;
        selectedPosition = -1;
        if (prev >= 0) notifyItemChanged(prev);
    }

    @NonNull
    @Override
    public WordViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_word, parent, false);
        return new WordViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WordViewHolder holder, int position) {

        holder.tvWord.setText(entries.get(position));
        holder.rbSelect.setChecked(position == selectedPosition);

        // ── Klik item → pilih/deselect ────────────────────────────
        holder.itemView.setOnClickListener(v -> {
            int prev = selectedPosition;
            selectedPosition = holder.getAdapterPosition();
            if (prev >= 0) notifyItemChanged(prev);
            notifyItemChanged(selectedPosition);
        });

        // ── Klik tombol Edit → buka EditWordActivity ──────────────
        holder.btnEdit.setOnClickListener(v -> {
            if (editListener != null) {
                editListener.onEditClick(holder.getAdapterPosition());
            }
        });
    }

    @Override
    public int getItemCount() {
        return entries.size();
    }

    static class WordViewHolder extends RecyclerView.ViewHolder {
        TextView    tvWord;
        RadioButton rbSelect;
        Button      btnEdit;

        WordViewHolder(@NonNull View itemView) {
            super(itemView);
            tvWord   = itemView.findViewById(R.id.tvWord);
            rbSelect = itemView.findViewById(R.id.rbSelect);
            btnEdit  = itemView.findViewById(R.id.btnEdit);
        }
    }
}